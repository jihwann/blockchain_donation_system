package com.org.comn.impl;

import java.io.File;
import java.io.IOException;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.org.comn.FileUploadService;

@Service("fileUploadService")
public class FileUploadServiceImpl implements FileUploadService{

	@Override
	public String filepload(MultipartFile file, HttpServletRequest request) throws Exception{
		String url = "";
		String fileName = file.getName();
		String originFilename1 = file.getOriginalFilename();
		int lastIndex = originFilename1.lastIndexOf("\\");
		String originFilename = originFilename1.substring(lastIndex+1); 

		/*
		 * String extName = originFilename.substring(originFilename.lastIndexOf("."),
		 * originFilename.length()); Long size = file.getSize();
		 */

		System.out.println("originFilename : " + originFilename);
		System.out.println("fileName : " + fileName);
		/*
		 * System.out.println("extensionName : " + extName);
		 * System.out.println("size : " + size);
		 */
        String rootPath = request.getSession().getServletContext().getRealPath("/");
        String imageUploadPath = rootPath+"resources/"+originFilename;
        System.out.println(imageUploadPath);
        File f = new File(imageUploadPath);
	
		try {
			file.transferTo(f);
		} catch (IllegalStateException e) {
			System.out.println("����");
		} catch (IOException e) {
			System.out.println("���Ͼ���");
		}
		
		return originFilename;
	}

}
