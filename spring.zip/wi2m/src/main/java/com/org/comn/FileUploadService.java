package com.org.comn;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService {

	String filepload(MultipartFile file, HttpServletRequest request) throws Exception;

}
