package com.org.notice.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class NoticeController {

	@RequestMapping(value="noticeList.do")
	public String notice() {
		return "notice/noticeList.wi2m";
	}
}
