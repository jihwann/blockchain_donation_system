package com.org.notice.service;

public interface NoticeService {

}
