package com.org.notice.service.impl;

import com.org.notice.service.NoticeService;

public class NoticeServiceImpl implements NoticeService{

}
