package com.org.notice.service.impl;

public interface NoticeDao {

}
