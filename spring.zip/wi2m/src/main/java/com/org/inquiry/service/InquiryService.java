package com.org.inquiry.service;

public interface InquiryService {

}
