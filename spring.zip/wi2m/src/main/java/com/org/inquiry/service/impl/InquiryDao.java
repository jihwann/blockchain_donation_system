package com.org.inquiry.service.impl;

public class InquiryDao {

}
