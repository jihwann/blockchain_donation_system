package com.org.inquiry.service.impl;

import com.org.inquiry.service.InquiryService;

public class InquiryServiceImpl implements InquiryService {

}
