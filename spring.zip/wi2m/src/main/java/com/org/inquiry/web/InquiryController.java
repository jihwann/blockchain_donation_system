package com.org.inquiry.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class InquiryController {

	@RequestMapping(value = "inquiryList.do")
	public String inquiry() {
		return "inquiry/inquiryList.wi2m";
	}
}
