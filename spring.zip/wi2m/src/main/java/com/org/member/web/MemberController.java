package com.org.member.web;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.org.member.service.MemberService;

@Controller
public class MemberController {

	@Resource(name = "memberService")
	private MemberService memberservice;
	
	//로그인
	@RequestMapping(value="login.do")
	public String login(@RequestParam(defaultValue="") String email, @RequestParam(defaultValue="") String password, HttpSession session) {
		/* HashMap<String, Object> loginList = memberservice.selectUserList(); */
		HashMap<String, Object> str = new HashMap<String, Object>();
		str.put("id",email);
		str.put("pwd",password);
		
		HashMap<String, Object> loginCheck = memberservice.selectMember(str);
		session.setAttribute("user", loginCheck);
		
		System.out.println(session.getAttribute("user"));
		
		if(loginCheck == null) {
			return "login/login.wi2m";
		}
		
		return "main/main.main";
	}
	
	//회원가입폼
	@RequestMapping(value="sign.do", method=RequestMethod.GET)
	public String sign() {
		
		return "login/sign.wi2m";
	}
	
	//회원가입전송
	@RequestMapping(value="sign.do",  method=RequestMethod.POST)
	public String signGO(@RequestParam(defaultValue="") String email,
	           @RequestParam(defaultValue="") String name,
	           @RequestParam(defaultValue="") String password) {
		
		HashMap<String, Object> str = new HashMap<String, Object>();
		str.put("id",email);
		str.put("pwd",password);
		str.put("name",name);
		str.put("usergrp",2);
		System.out.println(str);
		memberservice.insertMember(str);
		
		return "main/main.main";
	}
	
	//로그아웃
	@RequestMapping(value="logout.do")
	public String logout(HttpSession session) {
		session.removeAttribute("user");
		return "main/main.main";
	}
	
	//이메일 중복체크
	@RequestMapping(value="emailCheck.do")
	public String emailCheck(@RequestParam(defaultValue="") String email, Model model) {
		int check = 2;
		HashMap<String, Object> str = new HashMap<String, Object>();
		str.put("id",email);
		
		HashMap<String, Object> emailCheck = memberservice.selectEmail(str);
		
		if(emailCheck == null) {
			check = 2;
		} else {
			check = 1;
		}
		
		model.addAttribute("check", check);
		return "ajax/loginCheck";
	}
	
}
