package com.org.member.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface MemberService {

	HashMap<String, Object> selectUserList();

	HashMap<String, Object> selectMember(HashMap<String, Object> str);

	void insertMember(HashMap<String, Object> str);

	HashMap<String, Object> selectEmail(HashMap<String, Object> str);
	
}
