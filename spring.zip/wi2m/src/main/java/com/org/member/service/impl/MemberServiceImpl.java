package com.org.member.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Service;

import com.org.member.service.MemberService;

@Service("memberService")
public class MemberServiceImpl implements MemberService{
	
	@Resource(name = "sqlSession")
	private SqlSession sqlSession;
	
	private MemberMapper membermapper;

	@Override
	public HashMap<String, Object> selectUserList() {
		membermapper = sqlSession.getMapper(MemberMapper.class);
		return membermapper.selectUserList();
	}

	@Override
	public HashMap<String, Object> selectMember(HashMap<String, Object> str) {
		membermapper = sqlSession.getMapper(MemberMapper.class);
		return membermapper.selectMember(str);
	}

	@Override
	public void insertMember(HashMap<String, Object> str) {
		membermapper = sqlSession.getMapper(MemberMapper.class);
		membermapper.insertMember(str);
	}

	@Override
	public HashMap<String, Object> selectEmail(HashMap<String, Object> str) {
		membermapper = sqlSession.getMapper(MemberMapper.class);
		return membermapper.selectEmail(str);
	}
	
}
