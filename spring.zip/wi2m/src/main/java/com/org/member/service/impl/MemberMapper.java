package com.org.member.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface MemberMapper {

	HashMap<String, Object> selectUserList();

	HashMap<String, Object> selectMember(HashMap<String, Object> str);

	void insertMember(HashMap<String, Object> str);

	HashMap<String, Object> selectEmail(HashMap<String, Object> str);

}
