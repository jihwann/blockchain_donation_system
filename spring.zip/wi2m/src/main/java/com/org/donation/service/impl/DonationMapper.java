package com.org.donation.service.impl;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

public interface DonationMapper {

	void insertDonation(HashMap<String, Object> str);

	ArrayList<HashMap<String, Object>> selectDonationList();

	HashMap<String, Object> selectDonation(int dseq);

	void deleteDonation(int dseq);

	void updateDonation(HashMap<String, Object> str);

}
