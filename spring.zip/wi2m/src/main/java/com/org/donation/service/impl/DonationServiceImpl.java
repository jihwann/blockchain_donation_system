package com.org.donation.service.impl;


import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Service;

import com.org.donation.service.DonationService;

@Service("donationService")
public class DonationServiceImpl implements DonationService{
	
	@Resource(name = "sqlSession")
	private SqlSession sqlSession;
	
	private DonationMapper donationMapper;
	
	@Override
	public void insertDonation(HashMap<String, Object> str) {
		donationMapper = sqlSession.getMapper(DonationMapper.class);
		donationMapper.insertDonation(str);
	}

	@Override
	public ArrayList<HashMap<String, Object>> selectDonationList() {
		donationMapper = sqlSession.getMapper(DonationMapper.class);
		return donationMapper.selectDonationList();
	}

	@Override
	public HashMap<String, Object> Selectdonation(int dseq) {
		donationMapper = sqlSession.getMapper(DonationMapper.class);
		return donationMapper.selectDonation(dseq);
	}

	@Override
	public void deleteDonation(int dseq) {
		donationMapper = sqlSession.getMapper(DonationMapper.class);
		donationMapper.deleteDonation(dseq);
	}

	@Override
	public void updateDonation(HashMap<String, Object> str) {
		donationMapper = sqlSession.getMapper(DonationMapper.class);
		donationMapper.updateDonation(str);
	}
	
}
