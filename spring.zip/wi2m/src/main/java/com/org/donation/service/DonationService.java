package com.org.donation.service;

import java.util.ArrayList;
import java.util.HashMap;

public interface DonationService {

	void insertDonation(HashMap<String, Object> str);

	ArrayList<HashMap<String, Object>> selectDonationList();

	HashMap<String, Object> Selectdonation(int dseq);

	void deleteDonation(int dseq);

	void updateDonation(HashMap<String, Object> str);

}
