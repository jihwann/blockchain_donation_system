package com.org.donation.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.org.comn.FileUploadService;
import com.org.donation.service.DonationService;

@Controller
public class DonationController {
	
	@Resource(name = "donationService")
	private DonationService donationService;
	
	@Resource(name = "fileUploadService")
	private FileUploadService fileUploadService;
	
	//후원게시판 리스트
	@RequestMapping(value="donationList.do")
	public String login(Model model) {
		
		//리스트뽑아오기
		ArrayList<HashMap<String, Object>> donationList = donationService.selectDonationList();
		
		System.out.println(donationList);
		model.addAttribute("doList", donationList);
		return "donation/donationList.wi2m";
	}
	
	//후원게시판 작성폼
	@RequestMapping(value="donationWrite.do", method=RequestMethod.GET)
	public String donationForm() {
		return "donation/donationWrite.wi2m";
	}
	
	//후원게시판 작성
	@RequestMapping(value="donationWrite.do", method=RequestMethod.POST, headers = ("content-type=multipart/*"))
	public String donationWrite( HttpServletRequest request, HttpSession session,
								@RequestParam(defaultValue="") String title,
								@RequestParam(defaultValue="") String content,
								@RequestParam(defaultValue="") String write,
								@RequestParam(required=false) MultipartFile file) throws Exception {
		String fileName="";
		String originFilename1 = file.getOriginalFilename();
		System.out.println(originFilename1);
		System.out.println(originFilename1);
		if(originFilename1 != null || originFilename1 != "") {
			fileName = fileUploadService.filepload(file, request); 
			
		}
		
		Object sessionList = session.getAttribute("user");
		
		HashMap<String, Object> useInfoList = (HashMap<String, Object>) sessionList;
		HashMap<String, Object> str = new HashMap<String, Object>();
		str.put("id", useInfoList.get("id"));
		str.put("dtitle",title);
		str.put("dcontent",content);
		
		str.put("dfile", fileName);
		
		//해쉬맵에다가 정보 삽입 후 객체 전송 디비 저장
		donationService.insertDonation(str);
		
		return "redirect:donationList.do";
	}
	
	//후원게시판 상세조회 
	@RequestMapping(value="donationSelect.do")
	public String donationSelect(@RequestParam(defaultValue="") int dseq, Model model) {
		System.out.println(dseq);
		
		HashMap<String, Object> donationSelect = donationService.Selectdonation(dseq);
		
		model.addAttribute("doInfo", donationSelect);
		
		return "donation/donationSelect.wi2m";
	}
	
	//후원게시판 삭제
	@RequestMapping(value="donationDelete.do")
	public String donationDelete(@RequestParam(defaultValue="") int dseq) {
		System.out.println(dseq);
		
		donationService.deleteDonation(dseq);
		
		
		return "redirect:donationList.do";
	}
	
	//후원게시판 수정
	@RequestMapping(value="donationUpdate.do", method=RequestMethod.GET)
	public String donationUpdate(@RequestParam(defaultValue="") int dseq,  Model model) {
		System.out.println(dseq);
		
		HashMap<String, Object> donationSelect = donationService.Selectdonation(dseq);
		System.out.println(donationSelect);
		
		model.addAttribute("doInfo", donationSelect);
		
		
		return "donation/donationUpdate.wi2m";
	}
		
	//후원게시판 수정
	@RequestMapping(value="donationUpdate.do", method=RequestMethod.POST)
	public String donationUpdateGO( HttpServletRequest request, HttpSession session,
							      @RequestParam(defaultValue="") String dseq,
								  @RequestParam(defaultValue="") String title,
								  @RequestParam(defaultValue="") String content,
								  @RequestParam(defaultValue="") String write,
								  @RequestParam(required=false) MultipartFile file) throws Exception {
		
		String fileName="";
		
		if(file != null) {
			fileName = fileUploadService.filepload(file, request); 
			
		}
		
		Object sessionList = session.getAttribute("user");
		HashMap<String, Object> useInfoList = (HashMap<String, Object>) sessionList;
		HashMap<String, Object> str = new HashMap<String, Object>();
		str.put("dseq", dseq);
		str.put("dtitle",title);
		str.put("dcontent",content);
		str.put("dfile", fileName);
		System.out.println(str);
		
		donationService.updateDonation(str);
		
		return "redirect:donationList.do";
	}
	
}
